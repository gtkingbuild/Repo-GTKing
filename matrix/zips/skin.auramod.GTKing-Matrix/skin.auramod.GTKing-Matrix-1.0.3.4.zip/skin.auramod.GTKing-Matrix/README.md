# AuraMod for Matrix
# I no longer work on kodi or auramod  . If you notice any bugs in Matrix / kodi 19 with auramod , please submit fix's and i'll accept the PR's 

To install you need to install the following deps from these locations , they are all tested to be matrix compatable . but will need to be downloaded and installed from zip.  Note that besides tmdbhelper , the order matters ! 

1. Install jurialmunkey repo (kodi files source ) > https://jurialmunkey.github.io/

2. Install https://github.com/kodi-community-addons/script.module.thetvdb

3. Install https://github.com/kodi-community-addons/script.module.musicbrainz

4. Install https://github.com/kodi-community-addons/script.module.metadatautils

5. Install https://github.com/kodi-community-addons/script.module.cherrypy

6. Install https://github.com/kodi-community-addons/script.skin.helper.service

7. Install https://github.com/kodi-community-addons/script.skin.helper.widgets

8. Install TheMovieDb helper from Jurial's repo

