# LSP
A new vision of LSP by Someone Like You
