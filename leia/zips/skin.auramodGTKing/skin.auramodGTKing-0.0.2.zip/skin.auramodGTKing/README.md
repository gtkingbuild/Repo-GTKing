# Skin.auramod.GTKing v. 0.0.2 para tu Kodi

**auramodGTKing** con lleva al addons  **GTKing WIZARD v. 0.0.2**

Creado por el grupo **BEELINK/GT-KING / GTKINGPRO/GT1** de Telegram.

Para toda la información entrar en https://t.me/beelinkking

Fuente https://beelinkgtking2.github.io                  Nombre **GTKINGBUILD**





Esperamos que sea de su agrado y que sigas apostando por el   **GTKing WIZARD**

Gracias de parte del equipo: **GTKing**